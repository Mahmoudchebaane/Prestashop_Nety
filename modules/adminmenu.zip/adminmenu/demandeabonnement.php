<?php

if (!defined('_PS_VERSION_')) {
    exit;
}
class Hh_AdminMenu extends Module {
 
    public function __construct() {
 
        $this->name = 'hh_adminmenu';
        $this->displayName = 'HH admin menu';
        $this->tab = '';
        $this->version = '0.1.0';
        $this->author = 'hhhennes';
 
        parent::__construct();
 
        $this->displayName = $this->l('Hh Admin menu');
        $this->description = $this->l('Display again admin menu management');
        $this->ps_versions_compliancy = array('min' => '1.7.1', 'max' => _PS_VERSION_);
    }
 
    /**
     * Install Module
     * @return boolean
     */
    public function install() {
 
        if (!parent::install()) {
            return false;
        }
 
        //Ajout du liens vers la page des menus existants
        $tab = new Tab();
        $tab->class_name = 'AdminTabs';
        $tab->id_parent = Tab::getIdFromClassName('AdminAdvancedParameters');
        $languages = Language::getLanguages();
        foreach ($languages as $lang) {
            $tab->name[$lang['id_lang']] = $this->l('Menus');
        }
        try {
            $tab->save();
        } catch (Exception $e) {
            echo $e->getMessage();
            return false;
        }
 
        return true;
    }
 
    /**
     * Uninstall module
     * @return boolean
     */
    public function uninstall() {
 
        if ( !parent::uninstall() ) {
            return false ;
        }
 
        $id_tab = Tab::getIdFromClassName('AdminTabs');
        $tab = new Tab($id_tab);
        try{
            $tab->delete();
        } catch (Exception $e) {
            echo $e->getMessage();
            return false;
        }
 
        return true;
    }
 
}