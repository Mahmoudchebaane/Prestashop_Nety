<?php
/**
 * BINSHOPS REST API
 *
 * @author BINSHOPS | Best In Shops
 * @copyright BINSHOPS | Best In Shops
 * @license   http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
 * Best In Shops eCommerce Solutions Inc.
 *
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__FILE__) . '/classes/APIRoutes.php';

class Binshopsrest extends Module
{
    protected $config_form = false;

    public function __construct()
    {
        $this->name = 'binshopsrest';
        $this->tab = 'others';
        $this->version = '2.5.0';
        $this->need_instance = 0;

        /**
         * Set $this->bootstrap to true if your module is compliant with bootstrap (PrestaShop 1.6)
         */
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('PrestaShop REST API');
        $this->description = $this->l('This module exposes REST API endpoints for your Prestashop website.');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall my module?');

        $this->ps_versions_compliancy = array('min' => '1.7.7', 'max' => _PS_VERSION_);
        $this->module_key = 'b3c3c0c41d0223b9ff10c87b8acb65f5';
    }

    public function isUsingNewTranslationSystem()
    {
        return true;
    }

    /**
     * Don't forget to create update methods if needed:
     * http://doc.prestashop.com/display/PS16/Enabling+the+Auto-Update
     */
    public function install()
    {
        Configuration::updateValue('BINSHOPSREST_LIVE_MODE', false);
        Configuration::updateValue('BINSHOPSREST_FRONT_END_SERVER_URL', null);

        include(dirname(__FILE__) . '/sql/install.php');

        return parent::install() &&
            $this->registerHook('displayHeader') &&
            $this->registerHook('displayBackOfficeHeader') &&
            $this->registerHook('moduleRoutes') &&
            $this->registerHook('actionDispatcherBefore');
    }

    public function uninstall()
    {
        Configuration::deleteByName('BINSHOPSREST_LIVE_MODE');

        include(dirname(__FILE__) . '/sql/uninstall.php');

        return parent::uninstall();
    }

    /**
     * Load the configuration form
     */
    public function getContent()
    {
        /**
         * If values have been submitted in the form, process.
         */
        if (((bool)Tools::isSubmit('submitBinshopsrestModule')) == true) {
            $this->postProcess();
        }

        $this->context->smarty->assign('module_dir', $this->_path);

        $output = $this->context->smarty->fetch($this->local_path . 'views/templates/admin/configure.tpl');

        return $output;
    }

    /**
     * Create the form that will be displayed in the configuration of your module.
     */
    protected function renderForm()
    {
        $helper = new HelperForm();

        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $helper->module = $this;
        $helper->default_form_language = $this->context->language->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);

        $helper->identifier = $this->identifier;
        $helper->submit_action = 'submitBinshopsrestModule';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
            . '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFormValues(), /* Add values for your inputs */
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id,
        );

        return $helper->generateForm(array($this->getConfigForm()));
    }

    /**
     * Create the structure of your form.
     */
    protected function getConfigForm()
    {
        return array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Settings'),
                    'icon' => 'icon-cogs',
                ),
                'input' => array(
                    array(
                        'type' => 'switch',
                        'label' => $this->l('Live mode'),
                        'name' => 'BINSHOPSREST_LIVE_MODE',
                        'is_bool' => true,
                        'desc' => $this->l('Use this module in live mode'),
                        'values' => array(
                            array(
                                'id' => 'active_on',
                                'value' => true,
                                'label' => $this->l('Enabled')
                            ),
                            array(
                                'id' => 'active_off',
                                'value' => false,
                                'label' => $this->l('Disabled')
                            )
                        ),
                    ),
                    array(
                        'col' => 3,
                        'type' => 'text',
                        'prefix' => '<i class="icon icon-envelope"></i>',
                        'desc' => $this->l('Enter a valid email address'),
                        'name' => 'BINSHOPSREST_ACCOUNT_EMAIL',
                        'label' => $this->l('Email'),
                    ),
                    array(
                        'type' => 'password',
                        'name' => 'BINSHOPSREST_ACCOUNT_PASSWORD',
                        'label' => $this->l('Password'),
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                ),
            ),
        );
    }

    /**
     * Set values for the inputs.
     */
    protected function getConfigFormValues()
    {
        return array(
            'BINSHOPSREST_LIVE_MODE' => Configuration::get('BINSHOPSREST_LIVE_MODE', true),
            'BINSHOPSREST_ACCOUNT_EMAIL' => Configuration::get('BINSHOPSREST_ACCOUNT_EMAIL', 'contact@prestashop.com'),
            'BINSHOPSREST_ACCOUNT_PASSWORD' => Configuration::get('BINSHOPSREST_ACCOUNT_PASSWORD', null),
        );
    }

    /**
     * Save form data.
     */
    protected function postProcess()
    {
        $form_values = $this->getConfigFormValues();

        foreach (array_keys($form_values) as $key) {
            Configuration::updateValue($key, Tools::getValue($key));
        }
    }

    /**
     * Add the CSS & JavaScript files you want to be loaded in the BO.
     */
    public function hookDisplayBackOfficeHeader()
    {
        if (Tools::getValue('module_name') == $this->name) {
            $this->context->controller->addJS($this->_path . 'views/js/back.js');
            $this->context->controller->addCSS($this->_path . 'views/css/back.css');
        }
    }

    /**
     * Add the CSS & JavaScript files you want to be added on the FO.
     */
    public function hookDisplayHeader()
    {
        $this->context->controller->addJS($this->_path . '/views/js/front.js');
        $this->context->controller->addCSS($this->_path . '/views/css/front.css');
    }

    public function hookactionDispatcherBefore($controller)
    {
        if ($controller['controller_type'] === 1 && preg_match("#/rest/#", $_SERVER['REQUEST_URI'], $k)){
            preg_match('`rest/(.*)`', $_SERVER['REQUEST_URI'], $m);
            $s = explode('/', $m[0]);
            $_GET['fc'] = 'module';
            $_GET['module'] = $s[1];
            $_GET['controller'] = $s[2];
            $controller_name = $s[2];

            $module_name = Validate::isModuleName(Tools::getValue('module')) ? Tools::getValue('module') : '';

            $module = Module::getInstanceByName($module_name);
            $controller_class = 'PageNotFoundController';

            if (Validate::isLoadedObject($module) && $module->active) {
                $controllers = Dispatcher::getControllers(_PS_MODULE_DIR_ . "$module_name/controllers/front/");
                if (isset($controllers[strtolower($controller_name)])) {
                    include_once _PS_MODULE_DIR_ . "$module_name/controllers/front/{$controller_name}.php";
                    if (file_exists(
                        _PS_OVERRIDE_DIR_ . "modules/$module_name/controllers/front/{$controller_name}.php"
                    )) {
                        include_once _PS_OVERRIDE_DIR_ . "modules/$module_name/controllers/front/{$controller_name}.php";
                        $controller_class = $module_name . $controller_name . 'ModuleFrontControllerOverride';
                    } else {
                        $controller_class = $module_name . $controller_name . 'ModuleFrontController';
                    }
                }
            }

            if (!isset($controller) || !$module){
                header('Content-Type: ' . "application/json");

                echo json_encode([
                    'success' => true,
                    'message' => 'This endpoint is not defined.',
                    'code' => 410
                ]);
                die;
            }

            $controller = Controller::getController($controller_class);

            $controller->restRun();
        }
    }

    public function hookModuleRoutes()
    {
        return APIRoutes::getRoutes();
    }
}
